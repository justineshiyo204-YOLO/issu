<?php

$host = "localhost";
$user = "root";
$password ="";
$database = "logging_in";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn){
        die(mysqli_connect_error());
}

?>

<?php

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $passworsd = $_POST['password'];

    $form_data ="INSERT INTO login(email,password) VALUES ('$email','$password')";
    
    mysqli_query($conn, $form_data);
    
    header("location: dex-home.html");
}

$datas = "SELECT * FROM login";
$students = mysqli_query($conn, $datas);
?>