<!DOCTYPE html>
<html lang="en">

<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>dex-web</title>
          <link rel="icon" type="image/x-icon"
                    href="C:\Users\hp\Pictures\aa410e2b-323c-4346-aa79-56bc794ac441-1_all_494.png">
          <link rel="stylesheet" href="dex.css">
</head>

<body>
          <div class="container">
                    <div class="navbar">
                              <a href="dex-home.html">
                                        HOME
                              </a href="">
                              <a href="dex-about.html">
                                        ABOUT
                              </a href="">
                              <a href="dex-services.html">
                                        SERVICES
                              </a>
                              <a href="dex-contacts.html">
                                        CONTACTS
                              </a>
                    </div>

                    <div class="main">
                              <div class="services">
                                        <a href="transport">TRANSPORTATION</a>
                                        <a href="health">HEALTH</a>
                                        <a href="education">EDUCATION</a>
                                        <a href="banking">BANKING</a>
                                        <a href="payment">PAYMENTS</a>
                              </div>
                    </div>
</body>

</html>