<!DOCTYPE html>
<html>

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>dex-web</title>
   <link rel="icon" type="image/x-icon" href="C:\Users\hp\Pictures\aa410e2b-323c-4346-aa79-56bc794ac441-1_all_494.png">
   <link rel="stylesheet" href="dex.css">
</head>

<body>


   <div class="container">

      <div class="main">

         <form class="frm1">

            <table class="ft">
               <tr class="ft-tr">
                  <td class="ft-td">USERNAME:</td>
                  <td class="ft-td"><input type="text"></td>
               </tr>

               <tr class="ft-tr">
                  <td class="ft-td">EMAIL ACCOUNT:</td>
                  <td class="ft-td"><input type="email"></td>
               </tr>

               <tr class="ft-tr">
                  <td class="ft-td">PASSWORD:</td>
                  <td class="ft-td"><input type="password"></td>
               </tr>

               <tr class="ft-tr">
                  <td class="ft-td">PHONE NUMBER:</td>
                  <td class="ft-td"><input type="number"></td>
               </tr>

               <tr class="ft-tr">
                  <td class="ft-td">REGION:</td>
                  <td class="ft-td">
                     <select class="frm-sl">
                        <option>Dar es salaam</option>
                        <option>Pwani</option>
                        <option>Lindi</option>
                        <option>Tanga</option>
                        <option>Kilimanjaro</option>
                        <option>Arusha</option>
                        <option>Kagera</option>
                        <option>Dodoma</option>
                        <option>Singida</option>
                        <option>Moshi</option>
                        <option>Mbeya</option>
                        <option>Iringa</option>
                        <option>Mwanza</option>
                     </select>
                  </td>
               </tr>

            </table>
         </form>

      </div>

      <div class="footer">
         <a href="dex-welcome0.html">
            <button class="fo-btn-bck">
               BACK
            </button>
         </a>
         <a href="dex-home.html">
            <button class="fo-btn-nxt">
               NEXT
            </button>
         </a>
      </div>

   </div>
</body>

</html>