<!DOCTYPE html>
<html lang="en">

<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>dex-web</title>
          <link rel="icon" type="image/x-icon"
                    href="C:\Users\hp\Pictures\aa410e2b-323c-4346-aa79-56bc794ac441-1_all_494.png">
          <link rel="stylesheet" href="dex.css">
</head>

<body id="bd">

          <div class="container">
                    <div class="navbar">
                              <a href="dex-home.html">
                                        HOME
                              </a href="">
                              <a href="dex-about.html">
                                        ABOUT
                              </a href="">
                              <a href="dex-services.html">
                                        SERVICES
                              </a>
                              <a href="dex-contacts.html">
                                        CONTACTS
                              </a>
                    </div>

                    <div class="main">
                              <table class="abt-tbl">
                                        <tr>
                                                  <td>
                                                            <p class="par">
                                                                      Lorem ipsum dolor, sit amet consectetur
                                                                      adipisicing elit.
                                                                      Accusantium
                                                                      consequatur exercitationem deleniti impedit esse
                                                                      facere
                                                                      sapiente, debitis eos
                                                                      molestias. Voluptate doloremque sit velit,
                                                                      repellendus
                                                                      aspernatur autem nulla
                                                                      perferendis delectus facere.
                                                            </p>
                                                  </td>
                                                  <td>
                                                            <p class="par">
                                                                      Lorem, ipsum dolor sit amet consectetur
                                                                      adipisicing elit.
                                                                      Soluta eum, maxime eos
                                                                      esse optio facilis voluptatem dicta consequuntur
                                                                      itaque
                                                                      doloribus hic sed
                                                                      veritatis odio ducimus consequatur in? Et,
                                                                      veritatis porro!consequuntur
                                                                      itaque
                                                                      doloribus hic sed
                                                                      veritatis odio
                                                            </p>
                                                  </td>
                                        </tr>
                                        <tr>
                                                  <td>
                                                            <p class="par">
                                                                      Lorem ipsum dolor, sit amet consectetur
                                                                      adipisicing elit.
                                                                      Harum ipsum quam
                                                                      repudiandae,
                                                                      exercitationem maiores sequi tempora voluptas
                                                                      asperiores
                                                                      excepturi pariatur quia
                                                                      atque suscipit laborum incidunt esse non sit
                                                                      commodi facere.
                                                            </p>
                                                  </td>
                                                  <td>
                                                            <p class="par">
                                                                      Lorem ipsum dolor sit amet consectetur adipisicing
                                                                      elit.
                                                                      Saepe eveniet magni
                                                                      facere soluta quasi molestiae dolores distinctio
                                                                      ipsum eaque
                                                                      cumque maxime
                                                                      nulla, quisquam ducimus blanditiis quas dolorum et
                                                                      a
                                                                      dolorem.
                                                            </p>
                                                  </td>
                                        </tr>
                              </table>
                              </p>
                    </div>
</body>

</html>