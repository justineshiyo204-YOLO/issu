<!DOCTYPE html>
<html lang="en">

<head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>dex-web</title>
          <link rel="icon" type="image/x-icon"
                    href="C:\Users\hp\Pictures\aa410e2b-323c-4346-aa79-56bc794ac441-1_all_494.png">
          <link rel="stylesheet" href="dex.css">
</head>

<body id="bd">
          <div class="container">
                    <div class="navbar">
                              <a href="dex-home.html">
                                        HOME
                              </a href="">
                              <a href="dex-about.html">
                                        ABOUT
                              </a href="">
                              <a href="dex-services.html">
                                        SERVICES
                              </a>
                              <a href="dex-contacts.html">
                                        CONTACTS
                              </a>
                    </div>

                    <div class="main">
                              <p class="par">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur magnam
                                        fugit culpa dicta hic. Et vel commodi sit dolorum asperiores harum eaque,
                                        quaerat molestias nihil earum. Qui porro pariatur id! Lorem ipsum dolor sit amet
                                        consectetur, adipisicing elit. Nostrum odit veritatis nemo sint exercitationem
                                        iste nisi veniam magni neque quo. Corporis quod ad sed assumenda, quos possimus
                                        incidunt illum alias. Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                                        Facilis, nobis. Explicabo nostrum tenetur cupiditate, nihil nemo nobis ducimus
                                        veritatis esse aliquam modi beatae recusandae atque ea fugit incidunt ratione
                                        mollitia!<br>

                                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Temporibus aliquam,
                                        molestias corporis praesentium odit, minima omnis ex, magnam perferendis nam sit
                                        atque recusandae aspernatur sed explicabo ipsum dolor asperiores. Cum.lo Lorem,
                                        ipsum dolor sit amet consectetur adipisicing elit. Ad error itaque distinctio
                                        blanditiis cumque temporibus, explicabo, eum consequuntur alias quos illo,
                                        labore maxime? Commodi consequuntur consequatur esse consectetur quam ullam.
                              </p>
                    </div>
          </div>

</body>

</html>